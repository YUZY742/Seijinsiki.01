// =====================================================
// 外部リンク URL - ここを編集してください
// =====================================================
export const RSVP_FORM_URL = "https://example.com/rsvp";
export const PHOTO_ALBUM_URL = "https://example.com/photos";
export const INSTAGRAM_DM_URL = "https://instagram.com/direct/inbox/";
export const INSTAGRAM_PROFILE_URL = "https://instagram.com/example";

// =====================================================
// イベント詳細 - ここを編集してください
// =====================================================
export const EVENT_DETAILS = {
  date: "2026年1月10日（土）",
  time: "18:00〜20:30",
  venue: "〇〇ホテル 3F",
  fee: "8,000円",
  deadline: "2025年12月20日",
} as const;

// =====================================================
// テキストコンテンツ - ここを編集してください
// =====================================================
export const CONTENT = {
  hero: {
    title: "成人式同窓会のご案内",
    subtitle: "みんなで久しぶりに集まろう",
    description: "開催概要の確認、出欠回答、写真共有はこちらからお願いします",
    primaryCta: "出欠回答はこちら",
    secondaryCta: "写真アルバムはこちら",
  },
  message: {
    heading: "久しぶりにみんなで会えるのを楽しみにしています",
    body: "成人式をきっかけに、懐かしい仲間とまたつながれる場にしたいと思っています。ぜひ気軽に参加してください。",
  },
  photo: {
    heading: "当日の写真はこちら",
    description: "同窓会当日や終了後に、こちらから写真を見たり追加したりできます。",
    cta: "写真アルバムを開く",
  },
  faq: [
    {
      question: "途中参加はできますか？",
      answer: "はい、途中参加も大歓迎です。お仕事などの都合で遅れる場合も、ぜひお気軽にご参加ください。会場の詳細は出欠回答後にお知らせします。",
    },
    {
      question: "欠席でも連絡した方がいいですか？",
      answer: "はい、人数把握のため出欠回答フォームから欠席のご連絡をいただけると助かります。また、予定が変わった場合は幹事までお知らせください。",
    },
    {
      question: "写真は誰でも見られますか？",
      answer: "写真アルバムはリンクを知っている方のみアクセス可能です。参加者以外への共有はご遠慮ください。",
    },
  ],
  contact: {
    heading: "お問い合わせ",
    description: "質問や変更連絡がある場合は、幹事までInstagram DMでご連絡ください。",
    cta: "幹事へ連絡する",
  },
  footer: {
    title: "成人式同窓会",
    note: "ご不明点はInstagram DMまで",
  },
} as const;
