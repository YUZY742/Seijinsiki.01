"use client";

import { CONTENT } from "@/lib/constants";

export function MessageSection() {
  return (
    <section className="px-5 py-8">
      <div className="max-w-md mx-auto">
        <div className="relative bg-card rounded-2xl p-6 shadow-sm">
          {/* Decorative quote mark */}
          <div className="absolute -top-3 left-6 text-4xl text-accent font-serif">
            &ldquo;
          </div>
          
          <h2 className="text-lg font-bold text-foreground leading-relaxed pt-2 text-balance">
            {CONTENT.message.heading}
          </h2>
          
          <p className="mt-4 text-muted-foreground text-sm leading-relaxed">
            {CONTENT.message.body}
          </p>
          
          {/* Decorative line */}
          <div className="mt-6 w-12 h-0.5 bg-accent rounded-full" />
        </div>
      </div>
    </section>
  );
}
