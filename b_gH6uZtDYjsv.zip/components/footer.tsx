"use client";

import { CONTENT, INSTAGRAM_PROFILE_URL } from "@/lib/constants";
import { Instagram } from "lucide-react";

export function Footer() {
  return (
    <footer className="px-5 py-10 border-t border-border">
      <div className="max-w-md mx-auto text-center">
        {/* Title */}
        <p className="text-sm font-medium text-foreground">
          {CONTENT.footer.title}
        </p>
        
        {/* Note with Instagram link */}
        <p className="mt-2 text-xs text-muted-foreground">
          {CONTENT.footer.note}
        </p>
        
        {/* Instagram icon link */}
        <a
          href={INSTAGRAM_PROFILE_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center justify-center w-10 h-10 mt-4 rounded-full bg-muted text-muted-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
          aria-label="Instagram"
        >
          <Instagram className="h-5 w-5" />
        </a>
        
        {/* Copyright */}
        <p className="mt-6 text-xs text-muted-foreground/60">
          © {new Date().getFullYear()}
        </p>
      </div>
    </footer>
  );
}
