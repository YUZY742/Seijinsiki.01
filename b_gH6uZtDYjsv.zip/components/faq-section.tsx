"use client";

import { CONTENT } from "@/lib/constants";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { HelpCircle } from "lucide-react";

export function FAQSection() {
  return (
    <section className="px-5 py-8">
      <div className="max-w-md mx-auto">
        {/* Section header */}
        <div className="flex items-center gap-2 mb-4">
          <HelpCircle className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-bold text-foreground">
            よくある質問
          </h2>
        </div>
        
        <Accordion type="single" collapsible className="space-y-2">
          {CONTENT.faq.map((item, index) => (
            <AccordionItem
              key={index}
              value={`item-${index}`}
              className="bg-card rounded-xl border-0 shadow-sm px-4 data-[state=open]:shadow-md transition-shadow"
            >
              <AccordionTrigger className="text-left text-sm font-medium text-foreground py-4 hover:no-underline">
                {item.question}
              </AccordionTrigger>
              <AccordionContent className="text-sm text-muted-foreground leading-relaxed pb-4">
                {item.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}
