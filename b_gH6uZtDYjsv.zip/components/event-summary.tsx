"use client";

import { EVENT_DETAILS } from "@/lib/constants";
import { Card } from "@/components/ui/card";
import { CalendarDays, Clock, MapPin, Wallet, CalendarCheck } from "lucide-react";

const eventItems = [
  {
    icon: CalendarDays,
    label: "開催日",
    value: EVENT_DETAILS.date,
  },
  {
    icon: Clock,
    label: "時間",
    value: EVENT_DETAILS.time,
  },
  {
    icon: MapPin,
    label: "会場",
    value: EVENT_DETAILS.venue,
  },
  {
    icon: Wallet,
    label: "会費",
    value: EVENT_DETAILS.fee,
  },
  {
    icon: CalendarCheck,
    label: "回答締切",
    value: EVENT_DETAILS.deadline,
    highlight: true,
  },
];

export function EventSummary() {
  return (
    <section className="px-5 py-8">
      <div className="max-w-md mx-auto">
        <h2 className="sr-only">イベント概要</h2>
        <div className="grid gap-3">
          {eventItems.map((item) => (
            <Card
              key={item.label}
              className={`flex items-center gap-4 p-4 border-0 shadow-sm ${
                item.highlight 
                  ? "bg-accent/30 ring-1 ring-accent" 
                  : "bg-card"
              }`}
            >
              <div className={`flex items-center justify-center w-10 h-10 rounded-full ${
                item.highlight 
                  ? "bg-accent text-accent-foreground" 
                  : "bg-muted text-muted-foreground"
              }`}>
                <item.icon className="h-5 w-5" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs text-muted-foreground">{item.label}</p>
                <p className={`text-base font-medium ${
                  item.highlight ? "text-primary" : "text-foreground"
                }`}>
                  {item.value}
                </p>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
