"use client";

import { CONTENT, PHOTO_ALBUM_URL } from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { Images, ExternalLink } from "lucide-react";

export function PhotoSection() {
  return (
    <section className="px-5 py-8">
      <div className="max-w-md mx-auto">
        <div className="bg-muted rounded-2xl p-6 text-center">
          {/* Icon */}
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-accent/50 text-accent-foreground mb-4">
            <Images className="h-7 w-7" />
          </div>
          
          <h2 className="text-lg font-bold text-foreground">
            {CONTENT.photo.heading}
          </h2>
          
          <p className="mt-2 text-muted-foreground text-sm leading-relaxed">
            {CONTENT.photo.description}
          </p>
          
          <Button
            asChild
            variant="secondary"
            size="lg"
            className="mt-5 w-full h-12 text-base font-medium bg-secondary hover:bg-secondary/80 text-secondary-foreground"
          >
            <a
              href={PHOTO_ALBUM_URL}
              target="_blank"
              rel="noopener noreferrer"
            >
              {CONTENT.photo.cta}
              <ExternalLink className="ml-2 h-4 w-4" />
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
}
