"use client";

import { CONTENT, INSTAGRAM_DM_URL } from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { MessageCircle } from "lucide-react";

export function ContactSection() {
  return (
    <section className="px-5 py-8">
      <div className="max-w-md mx-auto">
        <div className="bg-primary/5 rounded-2xl p-6 text-center border border-primary/10">
          <h2 className="text-lg font-bold text-foreground">
            {CONTENT.contact.heading}
          </h2>
          
          <p className="mt-2 text-muted-foreground text-sm leading-relaxed">
            {CONTENT.contact.description}
          </p>
          
          <Button
            asChild
            size="lg"
            className="mt-5 h-12 px-8 text-base font-medium bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            <a
              href={INSTAGRAM_DM_URL}
              target="_blank"
              rel="noopener noreferrer"
            >
              <MessageCircle className="mr-2 h-5 w-5" />
              {CONTENT.contact.cta}
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
}
