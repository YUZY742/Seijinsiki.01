"use client";

import { CONTENT, RSVP_FORM_URL, PHOTO_ALBUM_URL } from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { Camera, Send } from "lucide-react";

export function HeroSection() {
  return (
    <section className="relative px-5 pt-12 pb-10">
      {/* Decorative accent */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-16 h-1 bg-accent rounded-full" />
      
      <div className="max-w-md mx-auto text-center">
        {/* Title */}
        <h1 className="text-2xl font-bold text-foreground leading-tight mt-6 text-balance">
          {CONTENT.hero.title}
        </h1>
        
        {/* Subtitle */}
        <p className="mt-3 text-lg text-primary font-medium">
          {CONTENT.hero.subtitle}
        </p>
        
        {/* Description */}
        <p className="mt-4 text-muted-foreground text-sm leading-relaxed">
          {CONTENT.hero.description}
        </p>
        
        {/* CTA Buttons */}
        <div className="mt-8 flex flex-col gap-3">
          {/* Primary CTA - RSVP */}
          <Button
            asChild
            size="lg"
            className="w-full h-14 text-base font-medium bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/20"
          >
            <a
              href={RSVP_FORM_URL}
              target="_blank"
              rel="noopener noreferrer"
            >
              <Send className="mr-2 h-5 w-5" />
              {CONTENT.hero.primaryCta}
            </a>
          </Button>
          
          {/* Secondary CTA - Photos */}
          <Button
            asChild
            variant="secondary"
            size="lg"
            className="w-full h-12 text-base font-medium bg-secondary hover:bg-secondary/80 text-secondary-foreground"
          >
            <a
              href={PHOTO_ALBUM_URL}
              target="_blank"
              rel="noopener noreferrer"
            >
              <Camera className="mr-2 h-5 w-5" />
              {CONTENT.hero.secondaryCta}
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
}
