import { HeroSection } from "@/components/hero-section";
import { EventSummary } from "@/components/event-summary";
import { MessageSection } from "@/components/message-section";
import { PhotoSection } from "@/components/photo-section";
import { FAQSection } from "@/components/faq-section";
import { ContactSection } from "@/components/contact-section";
import { Footer } from "@/components/footer";

export default function Home() {
  return (
    <main className="min-h-screen">
      <HeroSection />
      <EventSummary />
      <MessageSection />
      <PhotoSection />
      <FAQSection />
      <ContactSection />
      <Footer />
    </main>
  );
}
